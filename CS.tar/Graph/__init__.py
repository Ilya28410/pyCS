"""
The pyproblemsproofs.CS.Graph package provides you with tools to read docs in the pyproblemsproofs.CS.Graph.docs module and tools in the __init__.py
"""
class Edge:
    """
    This class helps you use edges a list of Edge and HyperEdge objects is an argument to the Graph class
    """
    def __init__():
        """
        docstring
        """
        pass
class HyperEdge:
    """
    This class helps you use hyperedges a list of HyperEdge and Edge objects is an argument to the Graph class
    """
    pass
class Graph:
    """
    This class provides an easy way to create and use graphs
    """
    def __init__(self,V,E):
        if type(self)!=Graph:
            raise TypeError("Argument self has to be the graph which is of type Graph")
        if type(V)!=int:
            raise TypeError("Argument V has to be the number of vertices which is of type int")
        if not (type(E) in [list,tuple,set]):
            raise TypeError("Argument E has to be the iterable containing edges of type Edge which is of type list,tuple,or set.")
        if any(type(e)!=Edge for e in E):
            TypeError("Argument E has to be the iterable containing edges of type Edge which is of type list,tuple,or set.")
        if type(E) in [tuple,set]:
            self.E=list(E)
        self.V=V
    def get_adj_matrix(self):
        vlist=[0]*self.V
        matrix=[]
        for i in range(self.V):
            matrix.append(vlist)
        for x,y in expression_list:
            pass
class Tree(Graph):
    """
    This class provides an easy way to create and use Binary Trees
    """
    pass